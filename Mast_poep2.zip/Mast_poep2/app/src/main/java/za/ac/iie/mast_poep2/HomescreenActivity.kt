package za.ac.iie.mast_poep2

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

// Data class for menu items using @Parcelize to handle Parcelable functionality automatically
@Parcelize
data class ChefMenuItems(
    val name: String?,
    val price: Double,
    val description: String?,
    val course: String?
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readDouble(),
        parcel.readString(),
        parcel.readString()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeDouble(price)
        parcel.writeString(description)
        parcel.writeString(course)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ChefMenuItems> {
        override fun createFromParcel(parcel: Parcel): ChefMenuItems {
            return ChefMenuItems(parcel)
        }

        override fun newArray(size: Int): Array<ChefMenuItems?> {
            return arrayOfNulls(size)
        }
    }
}

class HomescreenActivity : AppCompatActivity() {

    // Lists to hold the categorized menu items
    private val startersList = mutableListOf<ChefMenuItems>()
    private val mainCoursesList = mutableListOf<ChefMenuItems>()
    private val dessertsList = mutableListOf<ChefMenuItems>()

    // TextViews for displaying selected items
    private lateinit var selectedStartersTextView: TextView
    private lateinit var selectedMainCoursesTextView: TextView
    private lateinit var selectedDessertsTextView: TextView

    // Register the activity result launcher
    private val editItemsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            result.data?.let { data ->
                data.getParcelableArrayListExtra<ChefMenuItems>("startersList")?.let {
                    startersList.clear()
                    startersList.addAll(it)
                }
                data.getParcelableArrayListExtra<ChefMenuItems>("mainCoursesList")?.let {
                    mainCoursesList.clear()
                    mainCoursesList.addAll(it)
                }
                data.getParcelableArrayListExtra<ChefMenuItems>("dessertsList")?.let {
                    dessertsList.clear()
                    dessertsList.addAll(it)
                }
            }
        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homescreen)

        // Initialize TextViews for each course
        selectedStartersTextView = findViewById(R.id.startersTextView)
        selectedMainCoursesTextView = findViewById(R.id.mainCoursesTextView)
        selectedDessertsTextView = findViewById(R.id.dessertsTextView)

        // Adding built-in menu items
        addBuiltInMenuItems()

        // Setting up buttons for course selection
        val viewStartersButton: Button = findViewById(R.id.viewStartersButton)
        val viewMainCoursesButton: Button = findViewById(R.id.viewMainCoursesButton)
        val viewDessertsButton: Button = findViewById(R.id.viewDessertsButton)
        val doneButton: Button = findViewById(R.id.doneButton)

        // Display each category list in separate ListViews
        val startersListView: ListView = findViewById(R.id.startersListView)
        val mainCoursesListView: ListView = findViewById(R.id.mainCoursesListView)
        val dessertsListView: ListView = findViewById(R.id.dessertsListView)

        startersListView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, startersList.map { it.name })
        mainCoursesListView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mainCoursesList.map { it.name })
        dessertsListView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, dessertsList.map { it.name })

        viewStartersButton.setOnClickListener {
            showMenuDialog(startersList, "Select a Starter", selectedStartersTextView)
        }

        viewMainCoursesButton.setOnClickListener {
            showMenuDialog(mainCoursesList, "Select a Main Course", selectedMainCoursesTextView)
        }

        viewDessertsButton.setOnClickListener {
            showMenuDialog(dessertsList, "Select a Dessert", selectedDessertsTextView)
        }

        // "Done" button action
        doneButton.setOnClickListener {
            showSummaryDialog()
        }

        // Navigation buttons (edit items, filter items, back)
        val editItemsButton: Button = findViewById(R.id.editItemsButton)
        val filterItemsButton: Button = findViewById(R.id.filterItemsButton)
        val backButton: Button = findViewById(R.id.backButton)

        editItemsButton.setOnClickListener {
            val intent = Intent(this, EditItemsScreenActivity::class.java)
            editItemsLauncher.launch(intent)
        }

        filterItemsButton.setOnClickListener {
            val intent = Intent(this, FilterScreenActivity::class.java)
            startActivity(intent)
        }

        backButton.setOnClickListener {
            finish() // Going back to the previous screen
        }
    }

    private fun addBuiltInMenuItems() {
        // Adding starters
        startersList.addAll(listOf(
            ChefMenuItems("Sushi", 70.0, "Fresh sushi with assorted fillings", "Starter"),
            ChefMenuItems("Prawn Soup", 60.0, "Delicious prawn soup with aromatic spices", "Starter")
        ))

        // Adding main courses
        mainCoursesList.addAll(listOf(
            ChefMenuItems("Beef Chow Mein", 120.0, "Stir-fried beef with noodles and vegetables", "Main Course"),
            ChefMenuItems("Chicken Chow Mein", 110.0, "Stir-fried chicken with noodles and vegetables", "Main Course"),
            ChefMenuItems("Prawn Chow Mein", 130.0, "Stir-fried prawns with noodles and vegetables", "Main Course"),
            ChefMenuItems("Chicken Chop Suey", 115.0, "Stir-fried chicken with mixed vegetables", "Main Course")
        ))

        // Adding desserts
        dessertsList.addAll(listOf(
            ChefMenuItems("Peppermint Tart", 50.0, "Sweet and creamy peppermint tart", "Dessert"),
            ChefMenuItems("Chocolate Mousse Cake", 65.0, "Rich and velvety chocolate mousse cake", "Dessert")
        ))
    }

    private fun calculateAveragePrice(menuItems: List<ChefMenuItems>): Double {
        return if (menuItems.isNotEmpty()) {
            menuItems.map { it.price }.average()
        } else {
            0.0
        }
    }

    private fun showMenuDialog(menuItems: MutableList<ChefMenuItems>, title: String, selectedTextView: TextView) {
        val itemNames = menuItems.map { it.name ?: "Unnamed Item" }.toTypedArray()

        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)
        builder.setItems(itemNames) { _, which ->
            val selectedItem = menuItems[which]
            showItemDetails(selectedItem)
            updateSelectedItems(selectedItem, selectedTextView)
        }
        builder.show()
    }

    private fun showItemDetails(item: ChefMenuItems) {
        val descriptionDialog = AlertDialog.Builder(this)
            .setTitle(item.name)
            .setMessage("Price: R${item.price}\nDescription: ${item.description ?: "No description"}")
            .setPositiveButton("OK", null)
            .create()
        descriptionDialog.show()
    }

    private fun updateSelectedItems(item: ChefMenuItems, selectedTextView: TextView) {
        val currentText = selectedTextView.text.toString()
        val updatedText = if (currentText.isEmpty()) {
            "${item.name} - R${item.price}"
        } else {
            "$currentText\n${item.name} - R${item.price}"
        }
        selectedTextView.text = updatedText
    }

    private fun showSummaryDialog() {
        val selectedStarters = startersList.filter { selectedStartersTextView.text.contains(it.name ?: "") }
        val selectedMainCourses = mainCoursesList.filter { selectedMainCoursesTextView.text.contains(it.name ?: "") }
        val selectedDesserts = dessertsList.filter { selectedDessertsTextView.text.contains(it.name ?: "") }

        val startersTotalPrice = selectedStarters.sumOf { it.price }
        val mainCoursesTotalPrice = selectedMainCourses.sumOf { it.price }
        val dessertsTotalPrice = selectedDesserts.sumOf { it.price }

        val startersAvgPrice = calculateAveragePrice(selectedStarters)
        val mainCoursesAvgPrice = calculateAveragePrice(selectedMainCourses)
        val dessertsAvgPrice = calculateAveragePrice(selectedDesserts)

        val summaryMessage = buildString {
            append("Starters:\n")
            selectedStarters.forEach { append("${it.name} - R${it.price}\n") }
            append("Total: R$${startersTotalPrice}\n")
            append("Average Price: R$${"%.2f".format(startersAvgPrice)}\n\n")

            append("Main Courses:\n")
            selectedMainCourses.forEach { append("${it.name} - R${it.price}\n") }
            append("Total: R$${mainCoursesTotalPrice}\n")
            append("Average Price: R$${"%.2f".format(mainCoursesAvgPrice)}\n\n")

            append("Desserts:\n")
            selectedDesserts.forEach { append("${it.name} - R${it.price}\n") }
            append("Total: R$${dessertsTotalPrice}\n")
            append("Average Price: R$${"%.2f".format(dessertsAvgPrice)}\n")
        }

        val summaryDialog = AlertDialog.Builder(this)
            .setTitle("Summary of Selected Items")
            .setMessage(summaryMessage)
            .setPositiveButton("OK", null)
            .create()
        summaryDialog.show()
    }
}
