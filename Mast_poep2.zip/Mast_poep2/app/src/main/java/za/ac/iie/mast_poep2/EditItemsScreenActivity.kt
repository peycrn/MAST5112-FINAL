package za.ac.iie.mast_poep2

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

// Data class for menu items
data class ChefMenuItem(
    val name: String,
    val description: String,
    val price: Double,
    val course: String
)

class EditItemsScreenActivity : AppCompatActivity() {

    // Lists to categorize menu items
    private val startersList = mutableListOf<ChefMenuItem>()
    private val mainCoursesList = mutableListOf<ChefMenuItem>()
    private val dessertsList = mutableListOf<ChefMenuItem>()

    private lateinit var itemNameEditText: EditText
    private lateinit var itemDescriptionEditText: EditText
    private lateinit var itemPriceEditText: EditText
    private lateinit var courseSpinner: Spinner
    private lateinit var saveButton: Button
    private lateinit var removeButton: Button
    private lateinit var backButton: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_items_screen)

        // Initialize UI components
        itemNameEditText = findViewById(R.id.itemNameEditText)
        itemDescriptionEditText = findViewById(R.id.itemDescriptionEditText)
        itemPriceEditText = findViewById(R.id.itemPriceEditText)
        courseSpinner = findViewById(R.id.courseSpinner)
        saveButton = findViewById(R.id.saveButton)
        removeButton = findViewById(R.id.removeButton)
        backButton = findViewById(R.id.backButton)

        // Set up the course spinner
        val courses = arrayOf("Starters", "Main Courses", "Desserts")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, courses)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        courseSpinner.adapter = adapter

        // Save menu item categorized by course
        saveButton.setOnClickListener {
            saveMenuItem()
        }

        // Remove a menu item based on name
        removeButton.setOnClickListener {
            removeMenuItem()
        }

        // Back button to return to the home screen
        backButton.setOnClickListener {
            returnToHomeScreen()
        }
    }

    // Function to save or update a menu item
    private fun saveMenuItem() {
        val itemName = itemNameEditText.text.toString()
        val itemDescription = itemDescriptionEditText.text.toString()
        val itemPrice = itemPriceEditText.text.toString().toDoubleOrNull()
        val selectedCourse = courseSpinner.selectedItem.toString()

        if (itemName.isNotBlank() && itemDescription.isNotBlank() && itemPrice != null) {
            // Create or update a ChefMenuItem and add it to the appropriate list
            val newItem = ChefMenuItem(itemName, itemDescription, itemPrice, selectedCourse)
            addToCourseList(newItem)

            Toast.makeText(this, "$itemName added to $selectedCourse", Toast.LENGTH_SHORT).show()

            // Clear the fields after adding
            clearFields()
        } else {
            Toast.makeText(this, "Please fill in all fields correctly", Toast.LENGTH_SHORT).show()
        }
    }

    // Function to remove a menu item based on name
    private fun removeMenuItem() {
        val itemName = itemNameEditText.text.toString()
        val selectedCourse = courseSpinner.selectedItem.toString()
        var itemRemoved = false

        when (selectedCourse) {
            "Starters" -> itemRemoved = startersList.removeIf { it.name.equals(itemName, ignoreCase = true) }
            "Main Courses" -> itemRemoved = mainCoursesList.removeIf { it.name.equals(itemName, ignoreCase = true) }
            "Desserts" -> itemRemoved = dessertsList.removeIf { it.name.equals(itemName, ignoreCase = true) }
        }

        if (itemRemoved) {
            Toast.makeText(this, "$itemName removed from $selectedCourse", Toast.LENGTH_SHORT).show()
            clearFields()
        } else {
            Toast.makeText(this, "Item not found in $selectedCourse", Toast.LENGTH_SHORT).show()
        }
    }

    // Add or update item in the course list
    private fun addToCourseList(newItem: ChefMenuItem) {
        when (newItem.course) {
            "Starters" -> addItemToList(startersList, newItem)
            "Main Courses" -> addItemToList(mainCoursesList, newItem)
            "Desserts" -> addItemToList(dessertsList, newItem)
        }
    }

    // Utility function to add or replace an item in a list
    private fun addItemToList(list: MutableList<ChefMenuItem>, newItem: ChefMenuItem) {
        val existingItemIndex = list.indexOfFirst { it.name.equals(newItem.name, ignoreCase = true) }
        if (existingItemIndex >= 0) {
            list[existingItemIndex] = newItem // Replace if it exists
        } else {
            list.add(newItem) // Add new item
        }
    }

    // Function to clear input fields
    private fun clearFields() {
        itemNameEditText.text.clear()
        itemDescriptionEditText.text.clear()
        itemPriceEditText.text.clear()
    }

    // Function to return data to the HomeScreenActivity
    private fun returnToHomeScreen() {
        val intent = Intent(this, HomescreenActivity::class.java)
        intent.putParcelableArrayListExtra("startersList", ArrayList(startersList))
        intent.putParcelableArrayListExtra("mainCoursesList", ArrayList(mainCoursesList))
        intent.putParcelableArrayListExtra("dessertsList", ArrayList(dessertsList))
        startActivity(intent)
        finish()
    }
}

private fun Intent.putParcelableArrayListExtra(s: String, arrayList: java.util.ArrayList<ChefMenuItem>) {
    TODO("Not yet implemented")
}
