package za.ac.iie.mast_poep2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MenuItems(
    itemName: String,
    itemDescription: String,
    itemPrice: Double,
    selectedCourse: String
) : AppCompatActivity() {

    // Properties for displaying the details of a menu item (e.g., from intent extras)
    var price: String = ""
    var description: String? = null
    var name: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chef_menu_items) // Ensure this file exists in res/layout

        // Initialize these properties with data (e.g., from Intent extras or ViewModel)
        price = intent.getStringExtra("price") ?: "Unknown Price"
        description = intent.getStringExtra("description")
        name = intent.getStringExtra("name")

        // Use these properties in the UI (e.g., set to TextViews)
    }
}
