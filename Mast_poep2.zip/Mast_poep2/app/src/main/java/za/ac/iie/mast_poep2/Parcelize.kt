package za.ac.iie.mast_poep2

annotation class Parcelize
